﻿using IngredientsForRecipies.Data.Repositories;
using IngredientsForRecipies.Models;

namespace IngredientsForRecipies.Services
{
    public class IngredientService : ICrudService<IngredientItem, int>
    {
        private readonly ICrudRepository<IngredientItem, int> _ingredientRepository;
        public IngredientService(ICrudRepository<IngredientItem, int> ingredientRepository)
        {
            _ingredientRepository = ingredientRepository;
        }
        public void Add(IngredientItem element)
        {
            _ingredientRepository.Add(element);
            _ingredientRepository.Save();
        }
        public void Delete(int id)
        {
            _ingredientRepository.Delete(id);
            _ingredientRepository.Save();
        }
        public IngredientItem Get(int id)
        {
            return _ingredientRepository.Get(id);
        }
        public IEnumerable<IngredientItem> GetAll()
        {
            return _ingredientRepository.GetAll();
        }
        public void Update(IngredientItem old, IngredientItem newT)
        {
            old.Description = newT.Description;
            old.Status = newT.Status;
            _ingredientRepository.Update(old);
            _ingredientRepository.Save();
        }
    }
}
