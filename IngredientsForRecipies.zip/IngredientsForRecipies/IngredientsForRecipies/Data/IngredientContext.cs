﻿using IngredientsForRecipies.Models;
using Microsoft.EntityFrameworkCore;

namespace IngredientsForRecipies.Data.Repositories
{
    public class IngredientContext : DbContext
    {
        public IngredientContext(DbContextOptions<IngredientContext> options) : base(options)
        {
        }
        public DbSet<IngredientItem> IngredientItems { get; set; }
    }
}
