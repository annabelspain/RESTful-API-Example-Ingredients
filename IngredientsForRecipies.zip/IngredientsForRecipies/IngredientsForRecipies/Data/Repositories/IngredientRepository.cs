﻿using IngredientsForRecipies.Models;

namespace IngredientsForRecipies.Data.Repositories
{
    public class IngredientRepository : ICrudRepository<IngredientItem, int>
    {
        private readonly IngredientContext _ingredientContext;
        public IngredientRepository(IngredientContext ingredientContext)
        {
            _ingredientContext = ingredientContext ?? throw new
            ArgumentNullException(nameof(ingredientContext));
        }
        public void Add(IngredientItem element)
        {
            _ingredientContext.IngredientItems.Add(element);
        }
        public void Delete(int id)
        {
            var item = Get(id);
            if (item is not null) _ingredientContext.IngredientItems.Remove(Get(id));
        }
        public bool Exists(int id)
        {
            return _ingredientContext.IngredientItems.Any(u => u.Id == id);
        }
        public IngredientItem Get(int id)
        {
            return _ingredientContext.IngredientItems.FirstOrDefault(u => u.Id == id);
        }
        public IEnumerable<IngredientItem> GetAll()
        {
            return _ingredientContext.IngredientItems.ToList();
        }
        public bool Save()
        {
            return _ingredientContext.SaveChanges() > 0;
        }
        public void Update(IngredientItem element)
        {
            _ingredientContext.Update(element);
        }
    }
}
