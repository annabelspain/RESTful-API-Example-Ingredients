﻿using IngredientsForRecipies.Models;
using IngredientsForRecipies.Services;
using Microsoft.AspNetCore.Mvc;

namespace IngredientsForRecipies.Controllers
{
    [ApiController]
    [Route("[controller]")]//URL: http://localhost:5066/todo
    public class IngredientController : ControllerBase
    {
        private readonly ICrudService<IngredientItem, int> _ingredientService;
        public IngredientController(ICrudService<IngredientItem, int> ingredientService)
        {
            _ingredientService = ingredientService;
        }

        // GET all action
        [HttpGet] // auto returns data with a Content-Type of application/json
        public ActionResult<List<IngredientItem>> GetAll() => _ingredientService.GetAll().ToList();

        // GET by Id action
        [HttpGet("{id}")]
        public ActionResult<IngredientItem> Get(int id)
        {
            var ingredient = _ingredientService.Get(id);
            if (ingredient is null) return NotFound();
            else return ingredient;
        }

        // POST action
        [HttpPost]
        public IActionResult Create(IngredientItem ingredient)
        {
            // Runs validation against model using data validation attributes
            if (ModelState.IsValid)
            {
                _ingredientService.Add(ingredient);
                return CreatedAtAction(nameof(Create), new { id = ingredient.Id }, ingredient);
            }
            return BadRequest();
        }

        // PUT action
        [HttpPut("{id}")]
        public IActionResult Update(int id, IngredientItem ingredient)
        {
            var existingIngredientItem = _ingredientService.Get(id);
            if (existingIngredientItem is null || existingIngredientItem.Id != id)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                _ingredientService.Update(existingIngredientItem, ingredient);
                return NoContent();
            }
            return BadRequest();
        }

        // DELETE action
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var ingredient = _ingredientService.Get(id);
            if (ingredient is null) return NotFound();
            _ingredientService.Delete(id);
            return NoContent();
        }
    }
}
